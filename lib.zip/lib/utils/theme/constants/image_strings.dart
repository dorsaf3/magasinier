
/* -- App Image Strings -- */

/// This class contains all the App Images in String formats.
class TImages {

  // -- App Logos
  static const String darkAppLogo = "assets/logos/t-store-splash-logo-black.png";
  static const String lightAppLogo = "assets/logos/t-store-splash-logo-white.png";

  // -- Social Logos
  static const String google = "assets/logos/google-icon.png";
  static const String facebook = "assets/logos/facebook-icon.png";

  // -- Category Icons
  static const String sportIcon = "assets/icons/categories/icons8-bowling-64.png";
  static const String clothIcon = "assets/icons/categories/icons8-tailors-dummy-64.png";
  //static const String shoeIcon = "assets/icons/categories/icons8-shoes-64.png";
  static const String cosmeticsIcon = "assets/icons/categories/icons8-cosmetics-64.png";
  static const String salonIcon = "assets/icons/categories/salon1.jpg";
  static const String toyIcon = "assets/icons/categories/icons8-wooden-toy-car-50.png";
  static const String furnitureIcon = "assets/icons/categories/icons8-dining-chair-64.png";
  static const String jeweleryIcon = "assets/icons/categories/icons8-sparkling-diamond-64.png";
  static const String electronicsIcon = "assets/icons/categories/icons8-smartphone-64.png";

  // -- Brand Icons
  static const String nikeLogo = "assets/icons/brands/nike.png";
  static const String adidasLogo = "assets/icons/brands/adidas-logo.png";
  static const String appleLogo = "assets/icons/brands/apple-logo.png";
  static const String jordanLogo = "assets/icons/brands/jordan-logo.png";
  static const String pumaLogo = "assets/icons/brands/puma-logo.png";
  static const String zaraLogo = "assets/icons/brands/zara-logo.png";
  static const String kenwoodLogo = "assets/icons/brands/kenwood-logo.png";
  static const String hermanMillerLogo = "assets/icons/brands/herman-miller-logo.png";
  static const String ikeaLogo = "assets/icons/brands/ikea_logo.png";
  static const String acerlogo = "assets/icons/brands/acer_logo.png";

  // -- Animations
  static const String productsIllustration = "assets/images/animations/sammy-line-workout.gif";
  static const String productsSaleIllustration = "assets/images/animations/sammy-line-sale.png";
  static const String staticSuccessIllustration = "assets/images/animations/sammy-line-success.png";
  static const String deliveredInPlaneIllustration = "assets/images/animations/sammy-line-come-back-later.png";
  static const String deliveredEmailIllustration = "assets/images/animations/sammy-line-man-receives-a-mail.png";
  static const String verifyIllustration = "assets/images/animations/sammy-line-travel-backpack-with-passport-and-air-ticket.gif";

  // -- OnBoarding Texts
  static const String onBoardingImage1 = "assets/images/on_boarding_images/FURN1.png";
  static const String onBoardingImage2 = "assets/images/on_boarding_images/FURN1.png";
  static const String onBoardingImage3 = "assets/images/on_boarding_images/FURN1.png";

  // -- Products
  static const String salon1Image1 = "assets/images/products/salon1(1).jpg";
  static const String salon1Image2 = "assets/images/products/salon1(2).jpg";
  static const String salon1Image3 = "assets/images/products/salon1(3).jpg";
  static const String salon1Image4 = "assets/images/products/salon1(4).jpg";
  static const String salon1Image5 = "assets/images/products/salon1(5).jpg";
  static const String salon2Image1 = "assets/images/products/salon2(1).jpg";
  static const String salon2Image2 = "assets/images/products/salon2(2).jpg";
  static const String salon2Image3 = "assets/images/products/salon2(3).jpg";
  static const String salon2Image4 = "assets/images/products/salon2(4).jpg";
  static const String salon2Image5 = "assets/images/products/salon2(5).jpg";
  static const String salon3Image1 = "assets/images/products/salon3(1).jpg";
  static const String salon3Image2 = "assets/images/products/salon2(2).jpg";
  static const String salon3Image3 = "assets/images/products/salon3(3).jpg";
  static const String salon3Image4 = "assets/images/products/salon3(4).jpg";
  static const String salon3Image5 = "assets/images/products/salon3(5).jpg";
  static const String salon4Image1 = "assets/images/products/salon4(1).jpg";
  static const String salon4Image2 = "assets/images/products/salon4(2).jpg";
  static const String salon4Image3 = "assets/images/products/salon4(3).jpg";
  static const String salon4Image4 = "assets/images/products/salon4(4).jpg";
  static const String salon4Image5 = "assets/images/products/salon4(5).jpg";
  static const String salon5Image1 = "assets/images/products/salon5(1).jpg";
  static const String salon5Image2 = "assets/images/products/salon5(2).jpg";
  static const String salon5Image3 = "assets/images/products/salon5(3).jpg";
  static const String salon5Image4 = "assets/images/products/salon5(4).jpg";
  static const String salon5Image5 = "assets/images/products/salon5(5).jpg";
  static const String salon6Image1 = "assets/images/products/salon6(1).jpg";
  static const String salon6Image2 = "assets/images/products/salon6(2).jpg";
  static const String salon6Image3 = "assets/images/products/salon6(3).jpg";
  static const String salon6Image4 = "assets/images/products/salon6(4).jpg";
  static const String chamber1Image1 = "assets/images/products/chambre1(1).jpg";
  static const String chamber1Image2 = "assets/images/products/chambre1(2).jpg";
  static const String chamber1Image3 = "assets/images/products/chambre1(3).jpg";
  static const String chamber2Image1 = "assets/images/products/chambre2(1).jpg";
  static const String chamber2Image2 = "assets/images/products/chambre2(2).jpg";
  static const String chamber2Image3 = "assets/images/products/chambre2(3).jpg";
  static const String chamber2Image4 = "assets/images/products/chambre2(4).jpg";
  static const String chamber3Image1 = "assets/images/products/chambre3(1).jpg";
  static const String chamber3Image2 = "assets/images/products/chambre3(2).jpg";
  static const String chamber3Image3 = "assets/images/products/chambre3(3).jpg";
  static const String chamber3Image4 = "assets/images/products/chambre3(4).jpg";
  static const String chamber4Image1 = "assets/images/products/chambre4(1).jpg";
  static const String chamber4Image2 = "assets/images/products/chambre4(2).jpg";
  static const String chamber4Image3 = "assets/images/products/chambre4(3).jpg";
  static const String chamber4Image4 = "assets/images/products/chambre4(4).jpg";
  static const String chamber5Image1 = "assets/images/products/chambre5(1).jpg";
  static const String chamber5Image2 = "assets/images/products/chambre5(2).jpg";
  static const String chamber5Image3 = "assets/images/products/chambre5(3).jpg";
  static const String chamber5Image4 = "assets/images/products/chambre5(4).jpg";
  static const String chamber6Image1 = "assets/images/products/chambre6(1).jpg";
  static const String chamber6Image2 = "assets/images/products/chambre6(2).jpg";
  static const String chamber6Image3 = "assets/images/products/chambre6(3).jpg";
  static const String chamber6Image4 = "assets/images/products/chambre6(4).jpg";
  static const String chamber6Image5 = "assets/images/products/chambre6(5).jpg";
  static const String chamberENF1Image1 = "assets/images/products/chambreENF1(1).jpg";
  static const String chamberENF1Image2 = "assets/images/products/chambreENF1(2).jpg";
  static const String chamberENF1Image3 = "assets/images/products/chambreENF1(3).jpg";
  static const String chamberENF1Image4 = "assets/images/products/chambreENF1(4).jpg";
  static const String chamberENF2Image1 = "assets/images/products/chambreENF2(1).jpg";
  static const String chamberENF2Image2 = "assets/images/products/chambreENF2(2).jpg";
  static const String chamberENF2Image3 = "assets/images/products/chambreENF2(3).jpg";
  static const String chamberENF2Image4 = "assets/images/products/chambreENF2(4).jpg";
  static const String chamberENF3Image1 = "assets/images/products/chambreENF3(1).jpg";
  static const String chamberENF3Image2 = "assets/images/products/chambreENF3(2).jpg";
  static const String chamberENF3Image3 = "assets/images/products/chambreENF3(3).jpg";
  static const String chamberENF3Image4 = "assets/images/products/chambreENF3(4).jpg";
  static const String chamberENF3Image5 = "assets/images/products/chambreENF3(5).jpg";
  static const String chamberENF4Image1 = "assets/images/products/chambreENF4(1).jpg";
  static const String chamberENF4Image2 = "assets/images/products/chambreENF4(2).jpg";
  static const String chamberENF4Image3 = "assets/images/products/chambreENF4(3).jpg";
  static const String chamberENF4Image4 = "assets/images/products/chambreENF4(4).jpg";
  static const String chamberENF4Image5 = "assets/images/products/chambreENF4(5).jpg";
  static const String chamberENF5Image1 = "assets/images/products/chambreENF5(1).jpg";
  static const String chamberENF5Image2 = "assets/images/products/chambreENF5(2).jpg";
  static const String chamberENF5Image3 = "assets/images/products/chambreENF5(3).jpg";
  static const String chamberENF6Image1= "assets/images/products/chambreENF6(1).jpg";
  static const String chamberENF6Image2 = "assets/images/products/chambreENF6(2).jpg";
  static const String chamberENF6Image3 = "assets/images/products/chambreENF6(3).jpg";
  static const String chamberENF6Image4 = "assets/images/products/chambreENF6(4).jpg";
  static const String chamberENF6Image5 = "assets/images/products/chambreENF6(5).jpg";
  static const String cuisine1Image1 = "assets/images/products/cuisine1(1).jpg";
  static const String cuisine1Image2 = "assets/images/products/cuisine1(2).jpg";
  static const String cuisine1Image3 = "assets/images/products/cuisine1(3).jpg";
  static const String cuisine1Image4 = "assets/images/products/cuisine1(4).jpg";
  static const String cuisine1Image5 = "assets/images/products/cuisine1(5).jpg";
  static const String cuisine2Image1 = "assets/images/products/cuisine2(1).jpg";
  static const String cuisine2Image2 = "assets/images/products/cuisine2(2).jpg";
  static const String cuisine2Image3 = "assets/images/products/cuisine2(3).jpg";
  static const String cuisine2Image4 = "assets/images/products/cuisine2(4).jpg";
  static const String cuisine2Image5 = "assets/images/products/cuisine2(5).jpg";
  static const String cuisine3Image1 = "assets/images/products/cuisine3(1).jpg";
  static const String cuisine3Image2 = "assets/images/products/cuisine3(2).jpg";
  static const String cuisine3Image3 = "assets/images/products/cuisine3(3).jpg";
  static const String cuisine3Image4 = "assets/images/products/cuisine3(4).jpg";
  static const String cuisine4Image1 = "assets/images/products/cuisine4(1).jpg";
  static const String cuisine4Image2 = "assets/images/products/cuisine4(2).jpg";
  static const String cuisine4Image3 = "assets/images/products/cuisine4(3).jpg";
  static const String cuisine4Image4 = "assets/images/products/cuisine4(4).jpg";
  static const String cuisine5Image1 = "assets/images/products/cuisine5(1).jpg";
  static const String cuisine5Image2 = "assets/images/products/cuisine5(2).jpg";
  static const String cuisine5Image3 = "assets/images/products/cuisine5(3).jpg";
  static const String cuisine5Image4 = "assets/images/products/cuisine5(4).jpg";
  static const String cuisine5Image5 = "assets/images/products/cuisine5(5).jpg";
  static const String cuisine6Image1 = "assets/images/products/cuisine6(1).jpg";
  static const String cuisine6Image2 = "assets/images/products/cuisine6(2).jpg";
  static const String cuisine6Image3 = "assets/images/products/cuisine6(3).jpg";
  static const String cuisine6Image4 = "assets/images/products/cuisine6(4).jpg";







  // -- Product Reviews
  static const String userProfileImage1 = "assets/images/reviews/review_profile_image_1.jpg";
  static const String userProfileImage2 = "assets/images/reviews/review_profile_image_2.jpeg";
  static const String userProfileImage3 = "assets/images/reviews/review_profile_image_3.jpeg";

  //Banners
  static const String promoBanner1 = "assets/images/products/promo-banner-1.png";
  static const String promoBanner2 = "assets/images/products/promo-banner-2.png";
  static const String promoBanner3 = "assets/images/products/promo-banner-3.png";
  static const String banner1 = "assets/images/banners/banner_1.jpg";
  static const String banner2 = "assets/images/banners/banner_2.jpg";
  static const String banner3 = "assets/images/banners/banner_3.jpg";
  static const String banner4 = "assets/images/banners/banner_4.jpg";
  static const String banner5 = "assets/images/banners/banner_5.jpg";
  static const String banner6 = "assets/images/banners/banner_6.jpg";
  static const String banner7 = "assets/images/banners/banner_7.jpg";
  static const String banner8 = "assets/images/banners/banner_8.jpg";


  //Profile
  static const String user = "assets/images/user/user.png";

  // -- Payment Methods
  static const String applePay = "assets/icons/payment_methods/apple-pay.png";
  static const String googlePay = "assets/icons/payment_methods/google-pay.png";
  static const String creditCard = "assets/icons/payment_methods/credit-card.png";
  static const String masterCard = "assets/icons/payment_methods/master-card.png";
  static const String paypal = "assets/icons/payment_methods/paypal.png";
  static const String CB = "assets/icons/payment_methods/CB.png";

  static const String visa = "assets/icons/payment_methods/visa.png";
  static const String paystack = "assets/icons/payment_methods/paystack.png";
  static const String paytm = "assets/icons/payment_methods/paytm.png";
  static const String successfulPaymentIcon = "assets/icons/payment_methods/successful_payment_icon.png";
}

