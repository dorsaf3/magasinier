import 'package:flutter/material.dart';


import '../../../utils/colors.dart';
import '../../../utils/helpers/helper_functions.dart';
import '../../../utils/theme/constants/enums.dart';
import '../../../utils/theme/constants/image_strings.dart';
import '../../../utils/theme/constants/sizes.dart';
import '../custom_shapes/containers/rounded_container.dart';
import '../images/t_circular_image.dart';
import '../texts/t_brand_title_text_with_verified_icon.dart';
class TBrandCard extends StatelessWidget {
  const TBrandCard({
    super.key, this.showBorder, this.onTap,
  });


  final void Function()? onTap;
  final showBorder;

  @override
  Widget build(BuildContext context) {
    final isDark= THelperFunctions.isDarkMode(context);
    return GestureDetector(
      onTap: (){},
      child: TRoundedContainer(
        padding: const EdgeInsets.all(TSizes.sm),


        borderColor: Colors.grey,
        showBorder: false,
        backgroundColor: Colors.transparent,
        child: Row(
          children: [
            TCircularImages(
              image: TImages.clothIcon,
              isNetworkImage: false,
              backgroundColor: Colors.transparent,
              overlayColor: isDark ? TColors.white : Colors.black,
            ),
            /*Container(
        width: 56,
        height: 56,
        padding: const EdgeInsets.all(TSizes.sm),
        decoration: BoxDecoration(
          color: THelperFunctions.isDarkMode(context) ? TColors.black : TColors.white,
          borderRadius: BorderRadius.circular(100),
        ),
        child: Image(
          image: const AssetImage(TImages.clothIcon),
          color: THelperFunctions.isDarkMode(context) ? TColors.white : TColors.black,
        ),
      ),*/
            const SizedBox(height: TSizes.spaceBtwItems / 2),

            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TBrandTitleWithVerifiedIcon(title:  'Salonova' , brandTextSize: TextSizes.large),
                Text(
                  '80 produits',
                  overflow: TextOverflow.ellipsis ,
                  style: TextStyle(color:Colors.blueGrey),
                ),
              ],
            )



          ],
        ),
      ),


    );
  }
}






