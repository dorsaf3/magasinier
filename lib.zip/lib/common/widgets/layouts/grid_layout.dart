import 'package:flutter/material.dart';

import '../../../utils/theme/constants/sizes.dart';





class TGridLayout extends StatelessWidget {
  const TGridLayout({
    super.key,
     required this.itemCount,
    this.mainAxisEstent = 288,
    required this.intemBuilder,
  });
final int itemCount;
final double? mainAxisEstent;
final Widget? Function(BuildContext, int) intemBuilder;
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        itemCount: itemCount,
        shrinkWrap:true ,
        padding: EdgeInsets.zero,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate:  SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: TSizes.gridViewSpacing,
          crossAxisSpacing: TSizes.gridViewSpacing,
          mainAxisExtent: mainAxisEstent,
        ),
        itemBuilder: intemBuilder);
  }
}