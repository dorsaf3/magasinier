import 'package:flutter/material.dart';

class Livraison {
  final String id;
  final String destination;
  String status; // Modification pour rendre l'état modifiable

  Livraison({required this.id, required this.destination, required this.status});
}

class LivraisonScreen extends StatefulWidget {
  @override
  _LivraisonScreenState createState() => _LivraisonScreenState();
}

class _LivraisonScreenState extends State<LivraisonScreen> {
  List<Livraison> livraisons = [
    Livraison(id: '001', destination: 'Magasin A', status: 'En cours'),
    Livraison(id: '002', destination: 'Magasin B', status: 'Terminé'),
    Livraison(id: '003', destination: 'Magasin C', status: 'En cours'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('État de la livraison'),
      ),
      body: ListView.builder(
        itemCount: livraisons.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text('Livraison #${livraisons[index].id}'),
            subtitle: Text('Destination: ${livraisons[index].destination}'),
            trailing: DropdownButton<String>(
              value: livraisons[index].status,
              onChanged: (newValue) {
                setState(() {
                  livraisons[index].status = newValue!;
                });
              },
              items: <String>['En cours', 'Terminé', 'Annulé'].map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
          );
        },
      ),
    );
  }
}
