import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import '../../common/widgets/appbar/appbar.dart';
import '../../common/widgets/images/t_circular_image.dart';
import '../../common/widgets/texts/section_heading.dart';
import '../../features/personalization/screens/profile/widgets/profile_menu.dart';
import '../../utils/theme/constants/image_strings.dart';
import '../../utils/theme/constants/sizes.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Variables pour stocker les informations du profil
    String name = 'Benmebarek';
    String firstName = 'Nada Dorsaf';
    String userId = '23343';
    String email = 'nadad2@gmail.com';
    String phoneNumber = '+213 678 34 56';
    String gender = 'femme'; // Par défaut
    String birthDate = '25/01/2003'; // Par défaut

    return Scaffold(
      appBar: TAppBar(showBackArrow: true, title: Text('Profile')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(TSizes.defaultSpace),
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              child: Column(
                children: [
                  GestureDetector(
                    onTap: () {
                      // Ajoutez ici la logique pour changer la photo de profil
                    },
                    child: TCircularImages(image: TImages.user, width: 80, height: 80),
                  ),
                  TextButton(
                    onPressed: () {
                      // Ajoutez ici la logique pour changer la photo de profil
                    },
                    child: const Text('Changer la photo de profil'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: TSizes.spaceBtwSections),
            const Divider(),
            const SizedBox(height: TSizes.spaceBtwItems),
            const TSectionHeading(title: 'Profile information ', showActionButton: false),
            const SizedBox(height: TSizes.spaceBtwItems),

            // Champs modifiables avec ProfileFormField
            ProfileFormField(
              title: 'Name',
              initialValue: name,
              onChanged: (value) {
                // Mettre à jour la valeur de name avec la nouvelle valeur (value)
              },
            ),
            ProfileFormField(
              title: 'Prénom',
              initialValue: firstName,
              onChanged: (value) {
                // Mettre à jour la valeur de firstName avec la nouvelle valeur (value)
              },
            ),
            ProfileFormField(
              title: "ID d'utilisateur",
              initialValue: userId,
              onChanged: (value) {
                // Mettre à jour la valeur de userId avec la nouvelle valeur (value)
              },
            ),
            ProfileFormField(
              title: 'E-mail',
              initialValue: email,
              onChanged: (value) {
                // Mettre à jour la valeur de email avec la nouvelle valeur (value)
              },
            ),
            ProfileFormField(
              title: 'Numero télephone',
              initialValue: phoneNumber,
              onChanged: (value) {
                // Mettre à jour la valeur de phoneNumber avec la nouvelle valeur (value)
              },
            ),
            SizedBox(
              width: double.infinity,
              child: DropdownButtonFormField<String>(
                value: gender,
                decoration: InputDecoration(labelText: 'Genre'),
                onChanged: (newValue) {
                  // Mettre à jour la valeur de gender avec la nouvelle valeur (newValue)
                },
                items: <String>['femme', 'homme']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
            ),
            ProfileFormField(
              title: 'Date de naissance (j/m/a)',
              initialValue: birthDate,
              onChanged: (value) {
                // Mettre à jour la valeur de birthDate avec la nouvelle valeur (value)
              },
            ),

            const Divider(),
            const SizedBox(height: TSizes.spaceBtwItems),

            Center(
              child: TextButton(
                onPressed: () {
                  // Ajoutez ici la logique pour fermer le compte
                },
                child: const Text('fermer le compte', style: TextStyle(color: Colors.red)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ProfileFormField extends StatelessWidget {
  final String title;
  final String initialValue;
  final ValueChanged<String>? onChanged;

  const ProfileFormField({
    Key? key,
    required this.title,
    required this.initialValue,
    this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        initialValue: initialValue,
        decoration: InputDecoration(
          labelText: title,
        ),
        onChanged: onChanged,
      ),
    );
  }
}
