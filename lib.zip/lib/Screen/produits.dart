import 'package:flutter/material.dart';

class Produit {
  String nom;
  String photo;
  int quantite;
  String nomMagasin;
  String prix;

  Produit({required this.nom, required this.photo, required this.quantite, required this.nomMagasin, required this.prix});
}

class MesProduits extends StatefulWidget {
  const MesProduits({Key? key}) : super(key: key);

  @override
  _MesProduitsState createState() => _MesProduitsState();
}

class _MesProduitsState extends State<MesProduits> {
  List<Produit> produits = [
    Produit(nom: "Produit 1", photo: "assets/images/products/chambre1(1).jpg", quantite: 10, nomMagasin: "Magasin A", prix: "20000DA"),
    Produit(nom: "Produit 2", photo: "assets/images/products/chambre1(2).jpg", quantite: 5, nomMagasin: "Magasin B", prix: "23000DA"),
  ];

  TextEditingController nomController = TextEditingController();
  TextEditingController photoController = TextEditingController();
  TextEditingController quantiteController = TextEditingController();
  TextEditingController nomMagasinController = TextEditingController();
  TextEditingController prixController = TextEditingController();
  TextEditingController couponController = TextEditingController();
  TextEditingController pourcentageController = TextEditingController(); // Nouveau contrôleur pour le pourcentage de réduction

  bool isEditing = false;
  late Produit editedProduit;

  void appliquerCoupon(String coupon, Produit produit, double pourcentage) {
    // Calcul du nouveau prix après application du coupon
    double prix = double.parse(produit.prix.replaceAll('DA', ''));
    double reduction = pourcentage / 100; // Convertir le pourcentage en décimal
    double nouveauPrix = prix * (1 - reduction);

    // Mise à jour du prix du produit
    setState(() {
      produit.prix = '${nouveauPrix.toStringAsFixed(2)}DA';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mes Produits'),
      ),
      body: ListView.builder(
        itemCount: produits.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(produits[index].nom),
            subtitle: Text('Prix: ${produits[index].prix}'),
            leading: Image.asset(
              produits[index].photo,
              width: 80,
              height: 80,
            ),
            // Affichage de l'image
            onTap: () {
              setState(() {
                editedProduit = produits[index];
                isEditing = true;
                nomController.text = editedProduit.nom;
                photoController.text = editedProduit.photo;
                quantiteController.text = editedProduit.quantite.toString();
                nomMagasinController.text = editedProduit.nomMagasin;
                prixController.text = editedProduit.prix;
              });
              _showEditDialog();
            },
            trailing: IconButton(
              icon: Icon(Icons.delete),
              onPressed: () {
                _showDeleteConfirmationDialog(index);
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          isEditing = false;
          _showEditDialog();
        },
        child: Icon(Icons.add),
      ),
    );
  }

  _showEditDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: isEditing ? const Text('Modifier Produit', style: TextStyle(fontSize: 23)) : const Text('Ajouter Produit', style: TextStyle(fontSize: 23)),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: nomController,
                  decoration: InputDecoration(labelText: 'Nom du Produit'),
                ),
                TextField(
                  controller: photoController,
                  decoration: InputDecoration(labelText: 'Photo'),
                ),
                TextField(
                  controller: quantiteController,
                  decoration: InputDecoration(labelText: 'Quantité'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: nomMagasinController,
                  decoration: InputDecoration(labelText: 'Nom du Magasin'),
                ),
                TextField(
                  controller: prixController,
                  decoration: InputDecoration(labelText: 'Prix'),
                ),
                TextField(
                  controller: couponController,
                  decoration: InputDecoration(labelText: 'Coupon'),
                ),
                TextField(
                  controller: pourcentageController,
                  decoration: InputDecoration(labelText: 'Pourcentage de réduction (%)'),
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Annuler', style: TextStyle(fontSize: 18)),
              onPressed: () {
                setState(() {
                  isEditing = false;
                });
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: isEditing ?
              const Text('Modifier', style: TextStyle(fontSize: 18)) :
              const Text('Ajouter', style: TextStyle(fontSize: 18)),
              onPressed: () {
                setState(() {
                  if (isEditing) {
                    editedProduit.nom = nomController.text;
                    editedProduit.photo = photoController.text;
                    editedProduit.quantite = int.parse(quantiteController.text);
                    editedProduit.nomMagasin = nomMagasinController.text;
                    editedProduit.prix = prixController.text;
                    appliquerCoupon(couponController.text, editedProduit, double.parse(pourcentageController.text));
                  } else {
                    produits.add(Produit(
                      nom: nomController.text,
                      photo: photoController.text,
                      quantite: int.parse(quantiteController.text),
                      nomMagasin: nomMagasinController.text,
                      prix: prixController.text,
                    ));
                    Produit nouveauProduit = produits.last;
                    appliquerCoupon(couponController.text, nouveauProduit, double.parse(pourcentageController.text));
                  }
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  _showDeleteConfirmationDialog(int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return  AlertDialog(
          title: const Text('Confirmer la suppression', style: TextStyle(fontSize: 18)),
          content: const Text('Voulez-vous vraiment supprimer ce produit ?', style: TextStyle(fontSize: 18)),
          actions: <Widget>[
            TextButton(
              child:const Text('Annuler', style: TextStyle(fontSize: 18)),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Supprimer', style: TextStyle(fontSize: 18)),
              onPressed: () {
                setState(() {
                  produits.removeAt(index);
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
