import 'package:flutter/material.dart';
import 'package:magasinier1/Screen/produits.dart';


import 'package:flutter/material.dart';

class Coupon {
  String code;
  double reduction;

  Coupon({required this.code, required this.reduction});
}

class CouponPage extends StatefulWidget {
  const CouponPage({Key? key}) : super(key: key);

  @override
  _CouponPageState createState() => _CouponPageState();
}

class _CouponPageState extends State<CouponPage> {
  List<Coupon> coupons = [
    Coupon(code: 'REDUC10', reduction: 0.10),
    Coupon(code: 'REMAPRIL', reduction: 0.20),
  ];

  TextEditingController codeController = TextEditingController();
  TextEditingController reductionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Coupons'),
      ),
      body: ListView.builder(
        itemCount: coupons.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text('${coupons[index].code} - Réduction de ${coupons[index].reduction * 100}%'),
            trailing: IconButton(
              icon: Icon(Icons.delete),
              onPressed: () {
                _showDeleteConfirmationDialog(index);
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showAddCouponDialog();
        },
        child: Icon(Icons.add),
      ),
    );
  }

  _showAddCouponDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Ajouter un Coupon'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: codeController,
                  decoration: InputDecoration(labelText: 'Code du Coupon'),
                ),
                TextField(
                  controller: reductionController,
                  decoration: InputDecoration(labelText: 'Réduction (%)'),
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Annuler'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Ajouter'),
              onPressed: () {
                setState(() {
                  String code = codeController.text;
                  double reduction = double.parse(reductionController.text) / 100;
                  coupons.add(Coupon(code: code, reduction: reduction));
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  _showDeleteConfirmationDialog(int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirmer la suppression'),
          content: Text('Voulez-vous vraiment supprimer ce coupon ?'),
          actions: <Widget>[
            TextButton(
              child: Text('Annuler'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Supprimer'),
              onPressed: () {
                setState(() {
                  coupons.removeAt(index);
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
