import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:iconsax/iconsax.dart';
import 'package:magasinier1/features/personalization/screens/profile/widgets/profile_menu.dart';

import '../../../../common/widgets/appbar/appbar.dart';
import '../../../../common/widgets/images/t_circular_image.dart';
import '../../../../common/widgets/texts/section_heading.dart';
import '../../../../utils/theme/constants/image_strings.dart';
import '../../../../utils/theme/constants/sizes.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar:  TAppBar(showBackArrow: true, title: Text('Profile')),
      body: SingleChildScrollView(
        child: Padding(
            padding: const EdgeInsets.all(TSizes.defaultSpace),
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              child: Column(
                children: [
                  const TCircularImages(image: TImages.user , width: 80, height: 80),
                  TextButton(onPressed: (){}, child: const Text('Changer la photo de profile')),
                ],
              ),
            ),

            const  SizedBox(height: TSizes.spaceBtwSections),
            const Divider(),
            const  SizedBox(height: TSizes.spaceBtwItems),
            const TSectionHeading(title: 'Profile information ', showActionButton: false,),
            const  SizedBox(height: TSizes.spaceBtwItems),

            TProfileMenu(title: 'Name', value: 'Benmebarek',onPressed: (){}),
            TProfileMenu(title: 'Prénom', value: 'Nada Dorsaf',onPressed: (){}),

            const  SizedBox(height: TSizes.spaceBtwItems),
            const Divider(),
            const  SizedBox(height: TSizes.spaceBtwItems),

            TProfileMenu(title:"ID d'utilisateur", value: '23343',icon: Iconsax.copy ,onPressed: (){}),
            TProfileMenu(title: 'E-mail', value: 'nadad2@gmail.com',onPressed: (){}),
            TProfileMenu(title: 'Numero télephone  ', value: '+213 678 34 56',onPressed: (){}),
            TProfileMenu(title: 'Genre', value: 'femme',onPressed: (){}),
            TProfileMenu(title: 'Date de naissance', value: '25 janvier 2003',onPressed: (){}),
            const Divider(),
            const  SizedBox(height: TSizes.spaceBtwItems),

            Center(
              child: TextButton(
                onPressed: (){},
                child: const Text('fermer le compte',style: TextStyle(color:Colors.red)),
              ),
            )

          ],
        ),
        ),
      ),
    );
  }
}

