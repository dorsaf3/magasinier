import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';


import '../../../../common/widgets/appbar/appbar.dart';
import '../../../../common/widgets/costum_shapes/containers/primary_header_container.dart';
import '../../../../common/widgets/liste_tiles/settings_menu_title.dart';
import '../../../../common/widgets/liste_tiles/user_profile_tiles.dart';

import '../../../../common/widgets/texts/section_heading.dart';
import '../../../../utils/colors.dart';
import '../../../../utils/theme/constants/sizes.dart';
import '../profile/profile.dart';

class  SettingScreen extends StatelessWidget{
  const SettingScreen({super.key});

  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
          TPrimaryHeaderContainer(
            child: Column(
            children: [
              TAppBar(title:  Text('Mon compte',style: Theme.of(context).textTheme.headlineMedium!.apply(color: TColors.white)) ),



               TUserProfileTile(onPressed: () => Get.to(() =>  const ProfileScreen())),
              const SizedBox(height: TSizes.spaceBtwSections),
            ],
          ),
    ),
            //body
             Padding(padding: EdgeInsets.all(TSizes.defaultSpace),
            child: Column(
              children: [
                const TSectionHeading(title: 'gestion de compte', showActionButton: false),
                const SizedBox(height: TSizes.spaceBtwItems),

                const SettingMenuTile(icon: Iconsax.shopping_cart, title: 'Mon panier', subTitle: 'ajouter supprimer des produits et passer la commande'),
                const SettingMenuTile(icon: Iconsax.bag_tick, title: 'Mes achats', subTitle: 'en cours et commandes terminées'),
                const  SettingMenuTile(icon: Iconsax.discount_shape,title: 'My Coupons', subTitle: 'Liste de tous les coupons'),
                const SettingMenuTile(icon: Iconsax.notification, title: 'notification', subTitle: 'définir tous les types de message de notification'),
                const SettingMenuTile(icon: Iconsax.security_card, title: 'confidentialité du compte', subTitle: 'gérer l''utilisation des données et les comptes connectés'),

                const  SizedBox(height: TSizes.spaceBtwSections),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(onPressed: (){}, child: const Text('Logount')),
                ),
                const  SizedBox(height: TSizes.spaceBtwSections * 2.5),

              ],
            ),)
      ],
        ),
      ),
    );
  }
}

