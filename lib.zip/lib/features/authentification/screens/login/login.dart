import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:magasinier1/features/authentification/screens/login/widgets/login_from.dart';
import 'package:magasinier1/features/authentification/screens/login/widgets/login_header.dart';

import '../../../../common/styles/spacing_styles.dart';
import '../../../../common/widgets/login_signup/form_divider.dart';
import '../../../../common/widgets/login_signup/social_buttons.dart';
import '../../../../utils/theme/constants/sizes.dart';
import '../../../../utils/theme/constants/text_strings.dart';



class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: TSpacingStyle.paddingWithAppBarHeight,
          child: Column(
            children: [

            //logo,title and sub-title 
             const TLoginHeader(),

            //form 
             const TLoginForm(),

            //divider
              TFormDivider(dividerText: TTexts.orSignInWith.capitalize!),

             const SizedBox(height: TSizes.spaceBtwSections,),
            //footer
             const TSocialButtons()

            ],
          ),
        ) ,
      ),
      );

    
  }
}






