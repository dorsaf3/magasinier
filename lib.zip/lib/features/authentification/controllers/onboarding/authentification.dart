
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;


import '../../../../utils/theme/constants/api_constants.dart';

class AuthentificationController extends GetxController {
  RxBool isLoading = false.obs;

  Future signup(
      {
        required String nom,
        required String prenom,
        required String email,
        required String password,
        required String numero_tel,
        //required String type,

      }
      ) async {
    try {
      isLoading(true);

      var data = {
        'nom': nom,
        'prénom': prenom,
        'email': email,
        'password': password,
        'numéro_tél': numero_tel,
        //'type': type,
      };

      var response = await http.post(
        Uri.parse('${url}register'),
        headers: {
          'Accept' : 'application/json',
        },

        body: data,


      );
      Get.snackbar(
        'Error',
        json.decode(response.body)['message'],
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );

      if(response.statusCode==201){
        isLoading.value = false;
        print(json.decode(response.body) ) ;
      }else{
        isLoading.value = false;
        Get.snackbar(
          'Error',
          json.decode(response.body)['message'],
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
        print(json.decode(response.body) ) ;
      }
    } catch(e){
      isLoading.value = false;
      print(e.toString());
    }


  }


  Future login(
      {

        required String email,
        required String password,


      }
      ) async {
    try {
      isLoading(true);

      var data = {
        'email': email,
        'password': password,
      };

      var response = await http.post(
        Uri.parse('${url}login'),
        headers: {
          'Accept' : 'application/json',
        },
        body: data,

      );

      if(response.statusCode==200){
        isLoading.value = false;
        print(json.decode(response.body) ) ;
      }else{
        isLoading.value = false;
        Get.snackbar(
          'Error',
          json.decode(response.body)['message'],
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
        print(json.decode(response.body) ) ;
      }
    } catch(e){
      isLoading.value = false;
      print(e.toString());
    }


  }

}